sloppy_focus               = true
bypass_surface_visibility  = false
log_level                  = "slient" 


appearance = {
    gaps            = 10,     
    smart_gaps      = false,
    outer_border_px = 6,
    inner_border_px = 3,
    inner_border_color  = 0xc9cad1ff,
    outer_border_color   = 0x000000ff,
    inner_focus_color    = 0xc9cad1ff,
    outer_focus_color    = 0x000000ff,
    inner_urgent_color  = 0xff0000ff,
    outer_urgent_color  = 0x000000ff,
    root_color          = 0x000000ff,
}


input = {
    repeat_rate             = 35,
    repeat_delay            = 225,
    tap_to_click            = true,
    tap_and_drag            = true,
    drag_lock               = true,
    natural_scrolling       = false,
    disable_while_typing    = true,
    left_handed             = false,
    middle_button_emulation = false,
    scroll_method           = "2fg",     
    click_method            = "button_areas", 
    accel_profile           = "adaptive",   
    accel_speed             = 0.0,
}

rules = {
--   { app_id = "Gimp",    floating = true,  monitor = -1 },
--   { app_id = "firefox", tags = 1 << 8,    floating = false, monitor = -1 },
}

monitors = {
    { name = nil, mfact = 0.50, nmaster = 1, scale = 1.0,
      layout = "dwindle", x = -1, y = -1 },
}

autostart = {
    "dbus-update-activation-environment --systemd WAYLAND_DISPLAY XDG_SESSION_TYPE XDG_CURRENT_DESKTOP",
    "systemctl --user import-environment WAYLAND_DISPLAY XDG_SESSION_TYPE XDG_CURRENT_DESKTOP",
    "export XCURSOR_THEME='plan9'",
    "export XCURSOR_SIZE=24",
    "swaybg -i ~/Pictures/Wallpapers/gldrunk.jpg",
    "mako",
    "waybar",
}


keybinds = {
    { mods = {"logo"},          key = "w",     action = "spawn",  args = {"foot"} },
    { mods = {"logo"},          key = "b",action = "spawn",  args = {"zen"} },
    { mods = {"logo"},          key = "a", action = "spawn",  args = {"wofi", "--show", "drun" } },
    { mods = {"logo"},          key = "q",     action = "killclient" },
    { mods = {"logo"},          key = "v",     action = "togglefloating" },
    { mods = {"logo"},          key = "f",     action = "togglefullscreen" },
    { mods = {"logo"},          key = "g",     action = "togglegaps" },
    { mods = {"logo"},          key = "h",     action = "focusdir",  args = {"left"} },
    { mods = {"logo"},          key = "j",     action = "focusdir",  args = {"down"} },
    { mods = {"logo"},          key = "k",     action = "focusdir",  args = {"up"} },
    { mods = {"logo"},          key = "l",     action = "focusdir",  args = {"right"} },
    { mods = {"logo", "shift"}, key = "H",     action = "swapdir",   args = {"left"} },
    { mods = {"logo", "shift"}, key = "J",     action = "swapdir",   args = {"down"} },
    { mods = {"logo", "shift"}, key = "K",     action = "swapdir",   args = {"up"} },
    { mods = {"logo", "shift"}, key = "L",     action = "swapdir",   args = {"right"} },
    { mods = {"logo"},          key = "Tab",   action = "view" },
    { mods = {"logo"},          key = "0",     action = "view",      args = {"all"} },
    { mods = {"logo"},          key = "comma",  action = "focusmon", args = {"left"} },
    { mods = {"logo"},          key = "period", action = "focusmon", args = {"right"} },
    { mods = {"logo", "shift"}, key = "less",    action = "tagmon", args = {"left"} },
    { mods = {"logo", "shift"}, key = "greater", action = "tagmon", args = {"right"} },
    { mods = {"logo", "shift"}, key = "e",     action = "quit" },
    { mods = {}, key = "XF86AudioRaiseVolume",    action = "spawn",     args = {"wpctl", "set-volume", "@DEFAULT_SINK@", "5%+"} },
    { mods = {}, key = "XF86AudioLowerVolume",    action = "spawn",	args = {"wpctl", "set-volume", "@DEFAULT_SINK@", "5%-"} },
    { mods = {}, key = "XF86AudioMute",           action = "spawn",	args = {"wpctl", "set-mute", "@DEFAULT_SINK@", "toggle"} },
    { mods = {}, key = "XF86MonBrightnessUp",     action = "spawn",	args = {"brightnessctl", "set", "+5%"} },
    { mods = {}, key = "XF86MonBrightnessDown",   action = "spawn",	args = {"brightnessctl", "set", "5%-"} },
    { mods = {}, key = "Print",                   action = "spawn",	args = {"bash", "-c", "grim ~/Pictures/Screenshots/screenshot_$(date +%Y%m%d_%H%M%S).png"} },

}

for i = 1, 9 do
    local key  = tostring(i)
    local mask = 1 << (i - 1)
    table.insert(keybinds, { mods = {"logo"},                    key = key, action = "view",      args = {tostring(mask)} })
    table.insert(keybinds, { mods = {"logo", "shift"},           key = key, action = "tag",        args = {tostring(mask)} })
end

buttons = {
    { mods = {"logo"}, button = "left",   action = "moveresize",     args = {"move"} },
    { mods = {"logo"}, button = "middle", action = "togglefloating" },
    { mods = {"logo"}, button = "right",  action = "moveresize",     args = {"resize"} },
}
