{ config, lib, pkgs, inputs, ... }:

{
  imports =
    [ 
      ./hardware-configuration.nix
      ./everywheres.nix
      ./tlpconfig.nix
      ./mx330.nix
    ];

  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;
  boot.kernelPackages = pkgs.linuxPackages_latest;
  networking.firewall.checkReversePath = false;
  networking.hostName = "mitty-btw";

  networking.wireless.enable = false; 
  networking.wireless.iwd = {
    enable = true;
    settings = {
      General = {
        EnableNetworkConfiguration = true;
      };
     };
   };

  time.timeZone = "America/Caracas";

  i18n.defaultLocale = "en_US.UTF-8";
  
  programs.nix-ld.enable = true;
 
  services.xserver = {
      enable = true;
      autoRepeatDelay = 200;
      autoRepeatInterval = 35;
      windowManager.qtile.enable = true;
  };
     xdg.portal = {
      enable = true;
      wlr.enable = true;
      config.common.default = "*";
    };

  services.displayManager.ly.enable = true;
  services.libinput.enable = true;

   users.users.silverman = {
     isNormalUser = true;
     extraGroups = [ "wheel" "networkmanager" "storage" "disk" "keyd" "input" "video" ];
     packages = with pkgs; [
       tree
     ];
   };

   fileSystems."/mnt/my-data" = {
     device = "/dev/disk/by-uuid/1d95002e-ff0c-4b11-b3e0-0863a4d69b9e";
     fsType = "btrfs";
   };

   environment.sessionVariables = {
     XKB_DEFAULT_LAYOUT = "us,es";
     XKB_DEFAULT_OPTIONS = "grp:alt_shift_toggle";
   };

   nixpkgs.config.allowUnfree = true;
   environment.systemPackages = with pkgs; [
     inputs.zen-browser.packages.${pkgs.stdenv.hostPlatform.system}.default
     neovim 
     wget
     git
     wl-clipboard
     wf-recorder
     grim
     slurp
     unzip
     gcc
     xdg-utils
     shared-mime-info
     pciutils
     brightnessctl
     tlp
     xdg-terminal-exec
     mpv
     nemo
     swaybg
     zsh
     wofi
     nix-index
     mako
     foot
     graphviz
     imv
     zathura
     localsend
     wlr-randr
     taglib
     onlyoffice-desktopeditors
     halloy
     inputs.swindle.packages.${pkgs.stdenv.hostPlatform.system}.default
     inputs.zen-browser.packages.${pkgs.stdenv.hostPlatform.system}.default
     inputs.make2flake.packages.${pkgs.stdenv.hostPlatform.system}.default
     inputs.m701.packages.${pkgs.stdenv.hostPlatform.system}.default
     inputs.sb.packages.${pkgs.stdenv.hostPlatform.system}.default
     inputs.termipedia.packages.${pkgs.stdenv.hostPlatform.system}.default
     oh-my-zsh
     zsh-autosuggestions
     zsh-powerlevel10k
     zsh-syntax-highlighting
     gnome-keyring
     wireguard-tools
     openvpn
     powertop
     btop
     nvtopPackages.full
     qbittorrent
     mercurial
     gnumake
     busybox
     pkg-config
     efibootmgr
     curl
     gcc
     waybar
   ];

    fonts.packages = with pkgs; [
     nerd-fonts.jetbrains-mono
     nerd-fonts.caskaydia-cove
     nerd-fonts.meslo-lg
     meslo-lgs-nf
    ];

    environment.shells = with pkgs; [ zsh ];
    users.defaultUserShell = pkgs.zsh;
    environment.shellAliases = {
     nshell = "nix-shell --run $SHELL";
    };

  programs.zsh.enable = true;
  programs.zsh = {
   autosuggestions.enable = true;
   zsh-autoenv.enable = true;
   syntaxHighlighting.enable = true;
   shellAliases = {
   nixrebuild="sudo nixos-rebuild switch";
   cdnix="cd /etc/nixos";
   nixconfig="sudo nvim /etc/nixos/configuration.nix";
   nixflakes="sudo nvim /etc/nixos/flake.nix";
   nixsweets="sudo nvim /etc/nixos/sweets.nix";	
   };
  };

   system.userActivationScripts.zshrc = "touch .zshrc";
   environment.loginShellInit = ''
   '';
   programs.zsh.promptInit = "source ${pkgs.zsh-powerlevel10k}/share/zsh-powerlevel10k/powerlevel10k.zsh-theme
                              source ${pkgs.zsh-autosuggestions}/share/zsh-autosuggestions/zsh-autosuggestions.zsh
                              source ${pkgs.zsh-syntax-highlighting}/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh";

  nix.settings.experimental-features = [ "nix-command" "flakes" ];

  system.stateVersion = "26.05"; 

}

