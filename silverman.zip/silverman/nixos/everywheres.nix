{ config, ... }:

{
   imports = [
    ./sweets.nix
   ];
}
