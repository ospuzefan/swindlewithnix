{ config, pkgs, libs, inputs, ... }:

{
   imports = [
    inputs.spicetify-nix.nixosModules.default
   ];

   programs.steam = {
    enable = true;
    remotePlay.openFirewall = true;
    dedicatedServer.openFirewall = true;
   };

   environment.systemPackages = with pkgs; [
   fastfetch
   hyfetch
   vesktop
   steam
   heroic
   ripgrep
   nil
   nixpkgs-fmt
   nodejs
   yazi
   impala
   youtube-tui
   anup
   telegram-desktop
   iwd
   termusic
   ytermusic
   bluetui
   mangal
   manga-cli
   manga-tui
   ani-cli
   mov-cli
   sayonara
   lutris
   javaPackages.compiler.temurin-bin.jdk-21
   javaPackages.compiler.temurin-bin.jdk-25
   cl-wordle
   cava
   obs-studio
   ]; 

   programs.spicetify =
let
   spicePkgs = inputs.spicetify-nix.legacyPackages.${pkgs.stdenv.hostPlatform.system};
in
 {
     enable = true;
     theme = spicePkgs.themes.catppuccin;
     enabledExtensions = with spicePkgs.extensions; [
     adblock 
     ];
 };
}
